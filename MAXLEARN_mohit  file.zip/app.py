from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "database" / "maxlearn.db"

app = Flask(__name__)
app.secret_key = "change-this-secret-key-in-production"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            level TEXT NOT NULL,
            lessons INTEGER NOT NULL,
            icon TEXT NOT NULL,
            progress INTEGER DEFAULT 0
        );
    """)

    count = conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0]
    if count == 0:
        courses = [
            ("Python Programming", "Build strong Python fundamentals with practical projects.", "Beginner", 42, "🐍"),
            ("Web Development", "Create responsive websites with modern HTML, CSS and JavaScript.", "Beginner", 56, "🌐"),
            ("JavaScript", "Master modern JavaScript and interactive web applications.", "Intermediate", 48, "JS"),
            ("Data Science", "Analyze data and create useful data-driven applications.", "Intermediate", 50, "📊"),
            ("Artificial Intelligence", "Understand AI concepts and build intelligent applications.", "Advanced", 44, "AI"),
            ("Machine Learning", "Train, evaluate and deploy machine learning models.", "Advanced", 52, "🧠"),
            ("Cyber Security", "Learn practical security concepts and defensive techniques.", "Intermediate", 38, "🛡"),
            ("Full Stack Development", "Build complete applications from frontend to backend.", "Advanced", 64, "⚡")
        ]
        conn.executemany(
            "INSERT INTO courses(title, description, level, lessons, icon) VALUES (?, ?, ?, ?, ?)",
            courses
        )
    conn.commit()
    conn.close()


@app.route("/")
def index():
    conn = get_db()
    courses = conn.execute("SELECT * FROM courses LIMIT 8").fetchall()
    conn.close()
    return render_template("index.html", courses=courses)


@app.route("/courses")
def courses():
    conn = get_db()
    rows = conn.execute("SELECT * FROM courses ORDER BY id").fetchall()
    conn.close()
    return render_template("courses.html", courses=rows)


@app.route("/course/<int:course_id>")
def course_details(course_id):
    conn = get_db()
    course = conn.execute("SELECT * FROM courses WHERE id = ?", (course_id,)).fetchone()
    conn.close()
    if not course:
        return "Course not found", 404
    return render_template("course-details.html", course=course)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "error")
            return redirect(url_for("register"))

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(name, email, password) VALUES (?, ?, ?)",
                (name, email, generate_password_hash(password))
            )
            conn.commit()
            flash("Account created successfully. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account with this email already exists.", "error")
        finally:
            conn.close()

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "error")

    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db()
    courses = conn.execute("SELECT * FROM courses LIMIT 4").fetchall()
    conn.close()

    return render_template(
        "dashboard.html",
        user_name=session.get("user_name", "Student"),
        courses=courses
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
