const menu = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");
if (menu) menu.addEventListener("click", () => nav.classList.toggle("open"));

document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", e => {
    const id = link.getAttribute("href");
    const target = document.querySelector(id);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({behavior:"smooth"});
      nav?.classList.remove("open");
    }
  });
});

const reveal = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("visible");
  });
}, {threshold:.08});

document.querySelectorAll(".course-card,.project-card,.feature,.step,.metric,.dashboard-card").forEach(el => {
  el.classList.add("reveal");
  reveal.observe(el);
});
